package com.example.riken.etic.models;

public class HelloResponse {


}
